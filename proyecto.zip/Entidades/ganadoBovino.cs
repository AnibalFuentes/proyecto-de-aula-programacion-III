﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class ganadoBovino : ganado
    {
        public int idBovino { get; set; }
        public override string ToString()
        {
            return $"{idBovino} {raza} {edad} {peso} {enfermedad}";
        }
    }
}
