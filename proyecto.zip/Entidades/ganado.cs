﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class ganado
    {
       
        public string raza { get; set; }
        public string nombre { get; set; }
        public DateTime fnacimiento { get; set; }
        public int edad { get; set; }
        
        public string enfermedad { get; set; }
        public float peso { get; set; }

      

       
    }
}
